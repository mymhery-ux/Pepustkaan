<?php
session_start();
include '../lib/koneksi.php';

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id_user, password, role FROM users WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $res = $stmt->get_result();
    if($res->num_rows === 1){
        $row = $res->fetch_assoc();
        if(password_verify($password, $row['password'])){
            $_SESSION['user_id'] = $row['id_user'];
            $_SESSION['role'] = $row['role'];
            header('Location: ../admin/dashboard.php');
            exit;
        }
    }
    header('Location: ../index.php?err=1');
    exit;
}
header('Location: ../index.php');
