<?php
session_start();
function require_login(){
    if(!isset($_SESSION['user_id'])){
        header('Location: /index.php');
        exit;
    }
}
function require_role($roles = []){
    if(!isset($_SESSION['role'])){ header('Location: /index.php'); exit; }
    if(!in_array($_SESSION['role'], (array)$roles)){
        http_response_code(403);
        echo 'Akses ditolak.';
        exit;
    }
}
