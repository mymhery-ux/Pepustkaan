<?php
function log_activity($user_id, $activity, $conn){
    $u = (int)$user_id;
    $act = $conn->real_escape_string($activity);
    $conn->query("INSERT INTO log_aktifitas (id_user, aktifitas) VALUES ($u,'$act')");
}
