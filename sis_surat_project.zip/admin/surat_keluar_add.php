<?php
include '../lib/auth_middleware.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Tambah Surat Keluar</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Tambah Surat Keluar</h3>
<form method="post" action="../proses_surat_keluar.php" enctype="multipart/form-data">
    <div class="mb-3"><label>Nomor Surat</label><input class="form-control" name="nomor_surat" required></div>
    <div class="mb-3"><label>Tanggal Surat</label><input type="date" class="form-control" name="tanggal_surat" required></div>
    <div class="mb-3"><label>Tujuan</label><input class="form-control" name="tujuan" required></div>
    <div class="mb-3"><label>Perihal</label><textarea class="form-control" name="perihal" required></textarea></div>
    <div class="mb-3"><label>File Surat (PDF)</label><input type="file" class="form-control" name="file_surat" accept="application/pdf"></div>
    <div class="mb-3"><label>Status</label><select name="status_persetujuan" class="form-control"><option>Draft</option><option>Menunggu Persetujuan</option><option>Disetujui</option></select></div>
    <button class="btn btn-primary" type="submit" name="simpan_keluar">Simpan</button>
</form>
</div></body></html>
