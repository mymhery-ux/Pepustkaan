<?php
include '../lib/auth_middleware.php';
include '../lib/koneksi.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Surat Masuk</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Surat Masuk</h3>
<a class="btn btn-primary mb-3" href="surat_masuk_add.php">Tambah Surat Masuk</a>
<table class="table table-bordered">
<thead><tr><th>No</th><th>Nomor</th><th>Tanggal</th><th>Pengirim</th><th>Perihal</th><th>Lampiran</th><th>Status</th></tr></thead>
<tbody>
<?php
$q = $conn->query('SELECT * FROM surat_masuk ORDER BY tanggal_surat DESC');
$i=1;
while($r = $q->fetch_assoc()){
    echo '<tr>';
    echo '<td>'.$i++.'</td>';
    echo '<td>'.$r['nomor_surat'].'</td>';
    echo '<td>'.$r['tanggal_surat'].'</td>';
    echo '<td>'.$r['pengirim'].'</td>';
    echo '<td>'.$r['perihal'].'</td>';
    echo '<td>' . ($r['lampiran']? '<a href="../upload/'.$r['lampiran'].'" target="_blank">Download</a>':'-') . '</td>';
    echo '<td>'.$r['status'].'</td>';
    echo '</tr>';
}
?>
</tbody></table>
</div></body></html>
