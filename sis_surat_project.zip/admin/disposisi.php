<?php
include '../lib/auth_middleware.php';
include '../lib/koneksi.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Disposisi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Disposisi</h3>
<form method="post" action="../proses_disposisi.php">
    <div class="mb-3"><label>Pilih Surat Masuk</label>
        <select class="form-control" name="id_surat">
        <?php $q = $conn->query('SELECT id_surat_masuk, nomor_surat FROM surat_masuk'); while($r=$q->fetch_assoc()){ echo '<option value="'.$r['id_surat_masuk'].'">'.$r['nomor_surat'].'</option>'; } ?>
        </select>
    </div>
    <div class="mb-3"><label>Instruksi</label><textarea class="form-control" name="instruksi" required></textarea></div>
    <div class="mb-3"><label>Penerima (Staff ID)</label><input class="form-control" name="id_staff" required></div>
    <button class="btn btn-primary" type="submit" name="disposisi">Kirim Disposisi</button>
</form>

<hr>
<h4>Daftar Disposisi</h4>
<table class="table table-bordered"><thead><tr><th>No</th><th>Surat</th><th>Instruksi</th><th>Penerima</th><th>Status</th></tr></thead><tbody>
<?php $q = $conn->query('SELECT d.*, s.nomor_surat, u.nama as penerima FROM disposisi d LEFT JOIN surat_masuk s ON s.id_surat_masuk=d.id_surat_masuk LEFT JOIN users u ON u.id_user=d.id_staff ORDER BY d.tanggal_disposisi DESC'); $i=1; while($r=$q->fetch_assoc()){ echo '<tr><td>'.$i++.'</td><td>'.$r['nomor_surat'].'</td><td>'.$r['instruksi'].'</td><td>'.$r['penerima'].'</td><td>'.$r['status_tindak_lanjut'].'</td></tr>'; } ?>
</tbody></table>

</div></body></html>
