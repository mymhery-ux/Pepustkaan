<?php
include '../lib/auth_middleware.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Arsipkan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Arsipkan Surat</h3>
<form method="post" action="../proses_arsip.php">
    <div class="mb-3"><label>Jenis</label><select name="jenis" class="form-control"><option value="masuk">Masuk</option><option value="keluar">Keluar</option></select></div>
    <div class="mb-3"><label>Ref ID</label><input class="form-control" name="id_ref" required></div>
    <div class="mb-3"><label>Keterangan</label><textarea class="form-control" name="keterangan"></textarea></div>
    <button class="btn btn-primary" name="arsipkan" type="submit">Arsipkan</button>
</form>
</div></body></html>
