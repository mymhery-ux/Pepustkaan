<?php
include '../lib/auth_middleware.php';
include '../lib/koneksi.php';
require_login();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard - SIS-SURAT</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">SIS-SURAT</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="../auth/logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container py-4">
    <h3>Dashboard</h3>
    <div class="row">
        <?php
        $res = $conn->query('SELECT COUNT(*) as c FROM surat_masuk');
        $masuk = $res->fetch_assoc()['c'] ?? 0;
        $res = $conn->query('SELECT COUNT(*) as c FROM surat_keluar');
        $keluar = $res->fetch_assoc()['c'] ?? 0;
        ?>
        <div class="col-md-3">
            <div class="card mb-3"><div class="card-body"><h5>Surat Masuk</h5><h3><?php echo $masuk;?></h3></div></div>
        </div>
        <div class="col-md-3">
            <div class="card mb-3"><div class="card-body"><h5>Surat Keluar</h5><h3><?php echo $keluar;?></h3></div></div>
        </div>
    </div>

    <hr>
    <a class="btn btn-success" href="surat_masuk.php">Kelola Surat Masuk</a>
    <a class="btn btn-secondary" href="surat_keluar.php">Kelola Surat Keluar</a>
    <a class="btn btn-info" href="disposisi.php">Disposisi</a>
    <a class="btn btn-warning" href="arsip.php">Arsip</a>
    <a class="btn btn-dark" href="laporan.php">Laporan</a>
</div>
</body>
</html>
