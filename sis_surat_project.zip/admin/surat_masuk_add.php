<?php
include '../lib/auth_middleware.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Tambah Surat Masuk</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Tambah Surat Masuk</h3>
<form method="post" action="../proses_surat_masuk.php" enctype="multipart/form-data">
    <div class="mb-3"><label>Nomor Surat</label><input class="form-control" name="nomor_surat" required></div>
    <div class="mb-3"><label>Tanggal Surat</label><input type="date" class="form-control" name="tanggal_surat" required></div>
    <div class="mb-3"><label>Pengirim</label><input class="form-control" name="pengirim" required></div>
    <div class="mb-3"><label>Perihal</label><textarea class="form-control" name="perihal" required></textarea></div>
    <div class="mb-3"><label>Lampiran (PDF)</label><input type="file" class="form-control" name="lampiran" accept=".pdf"></div>
    <button class="btn btn-primary" type="submit" name="simpan">Simpan</button>
</form>
</div></body></html>
