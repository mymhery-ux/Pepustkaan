<?php
include '../lib/auth_middleware.php';
include '../lib/koneksi.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Surat Keluar</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Surat Keluar</h3>
<a class="btn btn-primary mb-3" href="surat_keluar_add.php">Tambah Surat Keluar</a>
<table class="table table-bordered">
<thead><tr><th>No</th><th>Nomor</th><th>Tanggal</th><th>Tujuan</th><th>Perihal</th><th>File</th><th>Status</th></tr></thead>
<tbody>
<?php
$q = $conn->query('SELECT * FROM surat_keluar ORDER BY tanggal_surat DESC');
$i=1;
while($r = $q->fetch_assoc()){
    echo '<tr>';
    echo '<td>'.$i++.'</td>';
    echo '<td>'.$r['nomor_surat'].'</td>';
    echo '<td>'.$r['tanggal_surat'].'</td>';
    echo '<td>'.$r['tujuan'].'</td>';
    echo '<td>'.$r['perihal'].'</td>';
    echo '<td>' . ($r['file_surat']? '<a href="../upload/'.$r['file_surat'].'" target="_blank">Download</a>':'-') . '</td>';
    echo '<td>'.$r['status_persetujuan'].'</td>';
    echo '</tr>';
}
?>
</tbody></table>
</div></body></html>
