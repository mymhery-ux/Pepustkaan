<?php
include '../lib/auth_middleware.php';
require_login();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Laporan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Laporan Surat Keluar</h3>
<form method="get" action="../proses_laporan_pdf.php" class="row g-2">
    <div class="col-auto"><input type="date" name="start" class="form-control"></div>
    <div class="col-auto"><input type="date" name="end" class="form-control"></div>
    <div class="col-auto"><button class="btn btn-primary" type="submit">Unduh PDF</button></div>
    <div class="col-auto"><a class="btn btn-success" href="../proses_laporan_excel.php">Unduh Excel</a></div>
</form>
</div></body></html>
