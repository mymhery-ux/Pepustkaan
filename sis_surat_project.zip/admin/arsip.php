<?php
include '../lib/auth_middleware.php';
include '../lib/koneksi.php';
require_login();
$q = $conn->query('SELECT * FROM arsip ORDER BY tanggal_arsip DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Arsip</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-4">
<h3>Arsip</h3>
<a class="btn btn-primary mb-3" href="arsip_add.php">Arsipkan Surat</a>
<table class="table table-bordered"><thead><tr><th>No</th><th>Jenis</th><th>Ref ID</th><th>File</th><th>Tanggal</th></tr></thead><tbody>
<?php $i=1; while($r=$q->fetch_assoc()){ echo '<tr><td>'.$i++.'</td><td>'.$r['jenis'].'</td><td>'.$r['id_ref'].'</td><td><a href="../upload/'.$r['file_arsip'].'" target="_blank">Download</a></td><td>'.$r['tanggal_arsip'].'</td></tr>'; } ?>
</tbody></table>
</div></body></html>
